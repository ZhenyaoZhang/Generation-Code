# from typing import Any, override, Iterable

from typing import Any, Iterable
from typing_extensions import override  # 修改为从 typing_extensions 导入

import torch
from diffusers.models.attention_processor import Attention, AttnProcessor
from torch import nn, Tensor, FloatTensor

CONTENT_PART_LEN = 3


class UnziploraLinear(nn.Module):
    def __init__(self, linear: nn.Linear, r: int):
        super().__init__()
        self.linear = linear
        self.s_lora_A = nn.Linear(self.linear.in_features, r, bias=False)
        self.s_lora_B = nn.Linear(r, self.linear.out_features, bias=False)
        self.s_lora_column_mask = nn.Parameter(
            (torch.empty(self.s_lora_B.out_features))
        )

        self.c_lora_A = nn.Linear(self.linear.in_features, r, bias=False)
        self.c_lora_B = nn.Linear(r, self.linear.out_features, bias=False)
        self.c_lora_column_mask = nn.Parameter(
            (torch.empty(self.c_lora_B.out_features))
        )
        self.init_weights()
        # self.register_full_backward_pre_hook(print)
        self.requires_grad_(True)
        self.linear.requires_grad_(False)
        # self.register_full_backward_pre_hook(funcy.partial(print, "UnziploraLinear.backward:"))
        # self.register_full_backward_pre_hook(lambda model, grad: print(f"{type(model)}.backward: grad.norm={grad[0].norm()}"))
        self.register_full_backward_pre_hook(
            lambda model, grad:None)

    def init_weights(self):
        # self.s_lora_A
        # for weight in [self._c_lora_column_mask, self._s_lora_column_mask, *(module.weight for module in [self.s_lora_A, self.s_lora_B, self.c_lora_A, self.c_lora_B])]:
        for weight in (module.weight for module in [self.s_lora_A, self.s_lora_B, self.c_lora_A, self.c_lora_B]):
            # if name!= "linear" and isinstance(module, nn.Linear):
            # print(f"init shape {weight.shape}")
            nn.init.xavier_uniform_(weight)
        for weight in self.c_lora_column_mask, self.s_lora_column_mask:
            nn.init.normal_(weight, mean=0., std=0.1)
            weight.requires_grad_()
            # weight.register_hook(
            #     lambda grad: print(f"lora mask got grad of shape {grad.shape} and norm {grad.norm()}")
            # )
            weight.register_hook(
                lambda grad: None)


    @property
    def unziplora_weights(self):
        res = {n: w for n, w in self.state_dict().items() if n != "linear"}
        assert "c_lora_column_mask" in res
        return res

            # nn.init.normal_(weight, mean=1., std=0.01)

            # if module.bias is not None:
            #     nn.init.zeros_(module.bias)
    @property
    def in_features(self) -> int:
        return self.linear.in_features

    @property
    def out_features(self) -> int:
        return self.linear.out_features

    def s_lora_mask_columns(self, x: Tensor) -> Tensor:
        return x * self.s_lora_column_mask

    def s_lora_forward(self, x: Tensor) -> Tensor:
        return self.s_lora_mask_columns(self.s_lora_B(self.s_lora_A(x)))

    def c_lora_mask_columns(self, x: Tensor) -> Tensor:
        return x * self.c_lora_column_mask

    def c_lora_forward(self, x: Tensor) -> Tensor:
        return self.c_lora_mask_columns(self.c_lora_B(self.c_lora_A(x)))

    def forward(self, x: Tensor) -> None:
        if self.training:
            # x_s = self.get_s_part(x)
            # x_c = self.get_c_part(x)
            x_s = x[:, CONTENT_PART_LEN:]
            x_c = x[:, :CONTENT_PART_LEN]
        else:
            x_s = x_c = x

        y = self.linear(x)
        y_s = self.s_lora_forward(x_s)
        y_c = self.c_lora_forward(x_c)

        # print(x.shape, x_s.shape, x_c.shape)
        # print(y.shape, y_s.shape, y_c.shape)

        if self.training:
            y.add_(torch.concat([y_s, y_c], dim=1))
        else:
        # residual = torch.concat([y_s, y_c], dim=1) if self.training else (y_s + y_c)
           y.add_(y_c)
           y.add_(y_s)
        return y

    # @property
    def get_regularization_loss(self) -> Tensor:
        assert self.s_lora_column_mask.requires_grad or self.c_lora_column_mask.requires_grad
        return (self.s_lora_column_mask * self.c_lora_column_mask).abs().mean()

    # def __getattr__(self, name: str) -> Any:
    #     # if name in self.overrides:
    #     #     return self.overrides[name]

    #     return getattr(self.linear, name)


class UnziploraAttentionWrapper(nn.Module):
    # def __init__(self, attn: Attention, processor: "UnziploraAttentionProcessor", **overrides):
    def __init__(self, attn: Attention, processor: "UnziploraAttentionProcessor", **overrides):
        super().__init__()
        self.__attn = attn

        self.__overrides = overrides
        self.processor = processor

    def get_attention_scores(self, q, k, mask):
        # if mask is not None:
        #     print(mask.shape)
        # print(q.shape)
        # print(k.shape)
        return type(self.__attn).get_attention_scores(self, q, k, mask)

    def __getattr__(self, name: str) -> Any:
        #     # if name in self.overrides:
        #     #     return self.overrides[name]

        #     # return getattr(self.attn, name)
        #     # return getattr(super().__getattribute__("attn"), name)
        #     # print(list(self.__dict__.keys()))
        try:

            return super().__getattr__(name)
        #         # return getattr(self.attn, name)
        except AttributeError:
            if name in self.__overrides:
                return self.__overrides[name]
            return getattr(self.__attn, name)


class UnziploraAttentionProcessor(AttnProcessor):
    @override
    def __init__(self, r: int):
        super().__init__()
        self.r = r
        self.wrappers: dict[Attention, Attention] = {}
        self.training = True

    def __repr__(self) -> str:
        # return super().__str__()
        return f"{self.__class__.__name__}({self.wrappers})"

    @override
    def __call__(self, attn: Attention, hidden_states: FloatTensor, encoder_hidden_states: Tensor | None = None,
                 attention_mask: Tensor | None = None, temb: FloatTensor | None = None, scale: float = 1, **kwargs) -> Tensor:
        attn = self.get_wrapped_attn(attn)
        return super().__call__(attn, hidden_states, encoder_hidden_states, attention_mask, temb, scale)

    def get_wrapped_attn(self, attn: Attention) -> Attention:
        if attn not in self.wrappers:
            self.wrappers[attn] = self._wrap_attn(attn)
        return self.wrappers[attn]

    def _wrap_attn(self, attn: Attention) -> Attention:
        to_k = UnziploraLinear(attn.to_k, r=self.r)
        assert attn.to_v
        to_v = UnziploraLinear(attn.to_v, r=self.r)
        return UnziploraAttentionWrapper(attn, processor=self, to_k=to_k, to_v=to_v)

    @property
    # def lora_params(self) -> list[nn.Parameter]:
    def lora_params(self) -> Iterable[nn.Parameter]:
        for wrapper in self.wrappers.values():
            yield from wrapper.lora_params
        # return [param for wrapper in self.wrappers.values() for param in wrapper.lora_params()]

    def eval(self):
        for wrapper in self.wrappers.values():
            wrapper.eval()
        self.training = False

    def train(self, mode: bool = True):
        for wrapper in self.wrappers.values():
            wrapper.train(mode)
        self.training = True
