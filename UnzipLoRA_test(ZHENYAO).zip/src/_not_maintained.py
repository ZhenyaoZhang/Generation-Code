import argparse
from pathlib import Path

import torch
from diffusers import StableDiffusionXLPipeline
from diffusers.utils import is_xformers_available, is_wandb_available
from huggingface_hub.utils import insecure_hashlib
from packaging import version
from tqdm.asyncio import tqdm

from data import PromptDataset
from logger import logger


def enable_xformer_memory_efficient_attention(unet):
    if is_xformers_available():
        import xformers

        xformers_version = version.parse(xformers.__version__)
        if xformers_version == version.parse("0.0.16"):
            logger.warning(
                "xFormers 0.0.16 cannot be used for training in some GPUs. If you observe problems during training, "
                "please update xFormers to at least 0.0.17. See https://huggingface.co/docs/diffusers/main/en/optimization/xformers for more details."
            )
        unet.use_xformers_mem_attention()
    else:
        raise ValueError(
            "xformers is not available. Make sure it is installed correctly"
        )


def prior_preservation_generate_class_images(accelerator, args: argparse.Namespace):
    class_images_dir = Path(args.class_data_dir)
    if not class_images_dir.exists():
        class_images_dir.mkdir(parents=True)
    cur_class_images = len(list(class_images_dir.iterdir()))
    if cur_class_images < args.num_class_images:
        torch_dtype = (
            torch.float16 if accelerator.device.type == "cuda" else torch.float32
        )
        if args.prior_generation_precision == "fp32":
            torch_dtype = torch.float32
        elif args.prior_generation_precision == "fp16":
            torch_dtype = torch.float16
        elif args.prior_generation_precision == "bf16":
            torch_dtype = torch.bfloat16
        pipeline = StableDiffusionXLPipeline.from_pretrained(
            args.pretrained_model_name_or_path,
            torch_dtype=torch_dtype,
            revision=args.revision,
        )
        pipeline.set_progress_bar_config(disable=True)

        num_new_images = args.num_class_images - cur_class_images
        logger.info(f"Number of class images to sample: {num_new_images}.")

        sample_dataset = PromptDataset(args.class_prompt, num_new_images)
        sample_dataloader = torch.utils.data.DataLoader(
            sample_dataset, batch_size=args.sample_batch_size
        )

        sample_dataloader = accelerator.prepare(sample_dataloader)
        pipeline.to(accelerator.device)

        for example in tqdm(
                sample_dataloader,
                desc="Generating class images",
                disable=not accelerator.is_local_main_process,
        ):
            images = pipeline(example["prompt"]).images

            for i, image in enumerate(images):
                hash_image = insecure_hashlib.sha1(image.tobytes()).hexdigest()
                image_filename = (
                    class_images_dir
                    / f"{example['index'][i] + cur_class_images}-{hash_image}.jpg"
                )
                image.save(image_filename)

        del pipeline
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


def get_prodigy_optimizer(args, params_to_optimize):
    try:
        import prodigyopt
    except ImportError:
        raise ImportError(
            "To use Prodigy, please install the prodigyopt library: `pip install prodigyopt`"
        )
    optimizer_class = prodigyopt.Prodigy
    if args.learning_rate <= 0.1:
        logger.warn(
            "Learning rate is too low. When using prodigy, it's generally better to set learning rate around 1.0"
        )
    if args.train_text_encoder and args.text_encoder_lr:
        logger.warn(
            f"Learning rates were provided both for the unet and the text encoder- e.g. text_encoder_lr:"
            f" {args.text_encoder_lr} and learning_rate: {args.learning_rate}. "
            f"When using prodigy only learning_rate is used as the initial learning rate."
        )
        # changes the learning rate of text_encoder_parameters_one and text_encoder_parameters_two to be
        # --learning_rate
        params_to_optimize[1]["lr"] = args.learning_rate
        params_to_optimize[2]["lr"] = args.learning_rate
    optimizer = optimizer_class(
        params_to_optimize,
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        beta3=args.prodigy_beta3,
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
        decouple=args.prodigy_decouple,
        use_bias_correction=args.prodigy_use_bias_correction,
        safeguard_warmup=args.prodigy_safeguard_warmup,
    )
    return optimizer


def get_optional_wandb(args):
    wandb = None
    if args.report_to == "wandb":
        _get_wandb()

    return wandb


def _get_wandb():
    if not is_wandb_available():
        raise ImportError(
            "Make sure to install wandb if you want to use it for logging during training."
        )
    import wandb
    return wandb
