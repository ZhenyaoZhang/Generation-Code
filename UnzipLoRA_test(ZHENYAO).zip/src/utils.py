from accelerate.utils import set_seed
from diffusers.models.attention_processor import Attention, AttnProcessor

    
from contextlib import contextmanager
import funcy
import torch

@contextmanager
def temp_patch(obj, **kwargs):
    # old_vals = funcy.walk_values(lambda x: getattr(obj, x), kwargs)
    old_vals = {x: getattr(obj, x) for x in kwargs if hasattr(obj, x)}
    # setattr(obj, attr, new_val)
    # print(dir(obj))
    if not hasattr(obj, '__dict__'):
        obj.__dict__ = {}
    obj.__dict__.update(kwargs)
    # for k, v in kwargs.items():
        # setattr(obj, k, v)

    yield
    # setattr(obj, attr, old_val)
    # obj.__dict__.update(old_vals)
    for k in kwargs:
        if k in old_vals:
            setattr(obj, k, old_vals[k])
        else:
            delattr(obj, k)

class AttnPatcher(AttnProcessor):
    methods_to_transfer = ["get_attention_scores"]

    def __init__(self, **kwargs):
        super().__init__()
        self.kwargs = kwargs

        # for name in self.methods_to_transfer:
        #     if hasattr(self, name):
        #         self.kwargs[name] = getattr(self, name)

    def __call__(self, attn: Attention, *args, **kwargs):
        # return temp_patch(self, **kwargs)
        for name in self.methods_to_transfer:
            if hasattr(self, name):
                new_method = funcy.partial(getattr(self, name), attn)
                # new_method.original = 
                self.kwargs[name] = new_method
                self.kwargs[f"original_{name}"] = getattr(attn, name)

        with temp_patch(attn, **self.kwargs):
            return super().__call__(attn, *args, **kwargs)

    def get_attention_scores(self, attn: Attention, *args, **kwargs):
        # print(self, attn, args, kwargs)
        print(attn.original_get_attention_scores)
        print(attn.get_attention_scores)
        res = attn.original_get_attention_scores(*args, **kwargs)
        # return res.where(res>0.1 , 0.0)
        return res[res>0.1]



if __name__ == '__main__':
    import torch
    attn = Attention(4, heads=1, dim_head=2)
    args = torch.randn(1, 1, 4, 4), torch.randn(1, 16, 4)
    print(attn(*args))
    patcher = AttnPatcher()
    attn.set_processor(patcher)
    print(attn(*args))
    # print(attn.get_attention_scores)
    # Test
    # obj = object()
    # class Obj:
    #     def __init__(self, a="a", b="b"):
    #         self.a = a
    #         # self.b = b
    # obj = Obj(11)
    # with temp_patch(obj, a=1, b=2):
    #     # print(obj.__dict__)
    #     print(obj.a, obj.b)
    # print(obj.a)
    # print(obj.b)


def set_seed_by_args(args):
    if args.seed is None:
        return None
    seed = args.seed
    set_seed(seed)
    return seed


def get_weight_dtype(accelerator):
    # weight_dtype = torch.float32
    if accelerator.mixed_precision == "fp16":
        weight_dtype = torch.float16
    elif accelerator.mixed_precision == "bf16":
        weight_dtype = torch.bfloat16
    else:
        weight_dtype = torch.float32
    return weight_dtype
