import typing
from pathlib import Path
from typing import Iterable, TypedDict

import funcy
import torch
from torch import nn, Tensor, tensor
# from torch import
from transformers import PreTrainedTokenizerBase, PreTrainedModel
from logger import logger

class TokenRegistratorState(TypedDict):
    tokens: list[str]
    embeddings: Tensor

class TokensRegistrator:
    def __init__(self, tokenizer: PreTrainedTokenizerBase, text_encoder: PreTrainedModel, new_tokens: Iterable[str] = None, initialize_from: str | Tensor | None = None, ):
        """
        Initialize the manager with a tokenizer and a text encoder.

        Args:
            tokenizer (PreTrainedTokenizerBase): HuggingFace tokenizer instance.
            text_encoder (PreTrainedModel): HuggingFace text encoder instance (e.g., CLIPTextModel).
        """
        self._only_new_requires_grad = False
        self.token_ids = []
        self.tokenizer = tokenizer
        self.text_encoder = text_encoder
        self.new_tokens: list[str] = [] # List of newly added tokens
        if new_tokens is not None:
            self.register_tokens(new_tokens, initialize_from=initialize_from)
        self.only_new_requires_grad_(True)
        # self.embeddings.register_full_backward_hook(self.backward_hook)
        # self.embeddings.register_full_backward_hook(self.module_backward_hook)
        self.embeddings.weight.register_hook(self.weight_backward_hook)

    def register_tokens(
            self, new_tokens: Iterable[str], initialize_from: str | Tensor | None = None
    ) -> Tensor:
        """
        Register new tokens in the tokenizer and initialize their embeddings.

        Args:
            new_tokens (Iterable[str]): List of new tokens to add.
            initialize_from (Optional[str]): Token to initialize embeddings from. If None, use random initialization.

        Returns:
            Tensor: A view on the new embeddings for further training.
        """
        new_tokens = list(new_tokens)  # Ensure iterable is converted to a list
        self.new_tokens.extend(new_tokens)

        # Add new tokens to the tokenizer
        num_added_tokens = self.tokenizer.add_tokens(new_tokens)
        if num_added_tokens != len(new_tokens):
            raise ValueError(f"Only {num_added_tokens} out of {len(new_tokens)}. The others already exist.")
        # if num_added_tokens == 0:
        #     raise ValueError(f"No new tokens were added, possibly they already exist: {new_tokens}")
        # logger.debug(f"Added {num_added_tokens} new tokens to the tokenizer.")

        # Resize the text encoder's embeddings to match the updated tokenizer
        self.text_encoder.resize_token_embeddings(len(self.tokenizer))

        # Get the embedding layer
        # embedding_layer = self.embeddings

        self.token_ids.extend(self.tokenizer.convert_tokens_to_ids(new_tokens))
        # embedding_layer.weight.data[token_ids] = loaded_embeddings

        # new_embeddings = embedding_layer.weight.data[-num_added_tokens:]
        # new_embeddings = self.embeddings.weight.data[self.token_ids]
        new_embeddings = self.new_embeddings_data
        if initialize_from is None:
            # Randomly initialize new embeddings
            torch.nn.init.normal_(new_embeddings, mean=0.0, std=0.01)
            logger.debug(f"Initialized new embeddings with random values.")
        else:
            if isinstance(initialize_from, Tensor):
                base_embedding = initialize_from
            elif isinstance(initialize_from, str):
                logger.debug(f"Initializing new embeddings from token '{initialize_from}'.")
                # Initialize new embeddings from an existing token
                base_token_id = self.tokenizer.convert_tokens_to_ids(initialize_from)
                assert base_token_id != self.tokenizer.unk_token_id, f"Token {initialize_from} not found in tokenizer."
                base_embedding = self.embeddings.weight.data[base_token_id].clone()
            else:
                t = type(initialize_from)
                if t == dict:
                    t = funcy.walk_values(type, t)
                raise ValueError(f"Invalid type for 'initialize_from': {t}.")
            new_embeddings.copy_(base_embedding)

        # Return a view on the new embeddings for further training
        # new_embeddings = embedding_layer.weight[-num_added_tokens:]
        return new_embeddings

    def only_new_requires_grad_(self, mode: bool = True):
        self._only_new_requires_grad = mode

    # def module_backward_hook(self, module, grad_in, grad_out):
    #     if not self._only_new_requires_grad:
    #         return grad_in
    #     grad = grad_in[0]
    #     if grad is None:
    #         logger.warning(f"Gradient of {module} is {grad_in} (grad_out is {grad_out}).")
    #         return
    #     logger.debug(f"hook grad_in: {grad.shape}")
    #     res = torch.zeros_like(grad)
    #     res[:, self.token_ids] = grad[:, self.token_ids]
    #     return (res,)

    def weight_backward_hook(self, grad: Tensor):
        if not self._only_new_requires_grad:
            return grad
        # grad = grad_in[0]
        if grad is None:
            logger.warning("Gradient of embedding is None.")
            return
        # logger.debug(f"Embedding got grad {grad.shape}")
        print(f"Embedding got grad {grad.shape}")
        res = torch.zeros_like(grad)
        try:
            for token_id in self.token_ids:
                res[token_id] = grad[token_id]
        except (RuntimeError, IndexError) as e:
            logger.exception(e)
            logger.error(f"res[:, token_id] = grad[:, token_id] failed for res.shape={res.shape}, grad.shape={grad.shape}")
            # return None
        # res.index_add_(1, tensor(self.token_ids), grad.index_select(1, tensor(self.token_ids)))
        return res
    @property
    def embeddings(self) -> nn.Embedding:
        return typing.cast(nn.Embedding, self.text_encoder.get_input_embeddings())

    def save_new_embeddings(self, file_path: str | Path) -> None:
        """
        Save the registered tokens and their embeddings to a file for later use.

        Args:
            file_path (str): Path to save the tokens and embeddings.
        """
        if not self.new_tokens:
            raise ValueError("No new tokens or embeddings to save.")

        # Transfer embeddings to CPU for saving
        torch.save(self.state, file_path)
        logger.debug(f"Saved {len(self.new_tokens)} new tokens and their embeddings to {file_path}.")

    def load_new_embeddings(self, file_path: str | Path) -> None:
        """
        Load tokens and embeddings from a file and register them with the tokenizer and model.

        Args:
            file_path (str): Path to the file containing saved tokens and embeddings.
        """
        self.state = torch.load(file_path)
        logger.debug(f"Successfully loaded and registered embeddings from {file_path}.")

    @property
    def state(self) -> TokenRegistratorState:
        """
        Return the current state of the new tokens and their embeddings for saving.

        Returns:
            Dict[str, Any]: A dictionary containing the tokens and embeddings.
        """
        return {
            "tokens": self.new_tokens,
            "embeddings": self.new_embeddings_data.detach().cpu(),
        }

    @property
    def new_embeddings_data(self) -> Tensor:
        return self.embeddings.weight.data[self.token_ids]

    @state.setter
    def state(self, data: TokenRegistratorState) -> None:
        """
        Load the tokens and embeddings state.

        Args:
            data (Dict[str, Any]): A dictionary containing tokens and embeddings.
        """
        self.register_tokens(data["tokens"], initialize_from=data["embeddings"])