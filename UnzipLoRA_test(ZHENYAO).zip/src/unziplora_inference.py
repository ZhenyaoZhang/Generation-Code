import argparse
import gc
from pathlib import Path
from typing import Callable, Literal

import numpy as np
import torch
from accelerate import Accelerator
from diffusers import StableDiffusionXLPipeline, DPMSolverMultistepScheduler, UNet2DConditionModel, DDPMScheduler, \
    AutoencoderKL
from torch import Tensor
from transformers import CLIPPreTrainedModel, PretrainedConfig, AutoTokenizer, PreTrainedTokenizerBase

from acceleration import get_accelerator, to_accelerator
from common_typing import Args, NEW_TOKENS
from logger import logger
from tokens_registrator import TokensRegistrator
from utils import get_weight_dtype
from _not_maintained import get_optional_wandb
from unziplora_unet import UnziploraUNet

import pprint


class UnziploraInference:
    # def __init__(self, args: argparse.Namespace) -> None:
    def __init__(self, args: Args) -> None:
        self.args = args
        self.accelerator = self.get_accelerator()
        logger.debug(pprint.pformat(args.__dict__))
        logger.debug(f"default device: {self.accelerator.device}")
        # torch.set_default_device(self.accelerator.device)
        torch.set_default_dtype(get_weight_dtype(self.accelerator))

        self.wandb = get_optional_wandb(args)
        self.vae = get_vae(self.args, accelerator=self.accelerator)
        self.token_registrators = self.create_token_registrators(load_embeddings=self.finetuned_weights_dir)

        # if self.finetuned_weights_dir:
        #     for i, registrator in enumerate(self.token_registrators, start=1):
        #         registrator.load_new_embeddings(self.finetuned_weights_dir/f"token_embeddings_{i}.pt")

        self.unet_unziplora = self.load_unet_unziplora(
            unziplora_weights_path=self.finetuned_weights_dir/"unziplora.pt" if self.finetuned_weights_dir else None
        )
        if self.args.gradient_checkpointing:
            self.enable_gradient_checkpointing()

        # self.pipeline = self.create_pipeline()
        # self.generator = self.create_generator()

    def create_token_registrators(self, load_embeddings: bool | Path = False) -> list[TokensRegistrator]:
        text_encoders = get_text_encoders(self.args, accelerator=self.accelerator)
        tokenizers = get_tokenizers(self.args)
        self.text_encoders = text_encoders  # TODO: eliminate usage use token_registrators
        self.tokenizers = tokenizers
        logger.debug("creating token registrators...")
        token_registrators = [
            TokensRegistrator(tokenizer=tokenizer, text_encoder=text_encoder)
            for tokenizer, text_encoder in zip(tokenizers, text_encoders)
        ]
        logger.debug("token registrators created. initializing/loading embeddings...")
        for i, token_registrator in enumerate(token_registrators, start=1):
            # initialize_from = None
            # if load_embeddings:
            #     with self.get_token_embeddings_path(i).open("rb") as f:
            #         initialize_from = torch.load(f)
            # initialize_from = torch.load(self.get_token_embeddings_path(i)) if load_embeddings else None
            if load_embeddings:
                token_registrator.load_new_embeddings(self.get_token_embeddings_path(i, d=load_embeddings if isinstance(load_embeddings, Path) else None))
            else:
                token_registrator.register_tokens(new_tokens=NEW_TOKENS)
        logger.debug("token registrators initialized/loaded.")
        return token_registrators

    def get_token_embeddings_path(self, i, d=None):
        return (d or self.output_dir) / f"token_embeddings_{i}.pt"

    def generate_images(self, vae, reload_pipeline: bool = None):
        get_pipeline: Callable[
            [ImageEncoder], StableDiffusionXLPipeline] = self.load_pipeline if reload_pipeline else self.create_pipeline
        pipeline: StableDiffusionXLPipeline = get_pipeline(vae)
        generator = self.create_generator()

        # validation_prompt = self.args.validation_prompt or self.args.instance_prompt

        validation_prompt = "An elephant in the style of [S]"



        # num_validation_images = self.args.num_validation_images

        num_validation_images = 2

        logger.debug(f"validation: {num_validation_images}*'{validation_prompt}'")
        # num_validation_images = pipeline.lr_scheduler.num_validation_images
        # num_validation_images = pipeline.scheduler.num_validation_images
        pipeline_kwargs = dict(prompt=validation_prompt, num_images_per_prompt=num_validation_images, height=1024, width=1024, generator=generator)
        logger.debug(pipeline_kwargs)
        images = pipeline(**pipeline_kwargs).images
        logger.debug(str(images))
        del pipeline
        del generator
        clear_mem()
        return images

    def load_pipeline(self, vae):
        #TODO: reload models followed by create pipeline?
        del self.unet_unziplora
        self.unet_unziplora = self.load_unet_unziplora(unziplora_weights_path=self.output_dir / "unziplora.pt")
        del self.token_registrators
        self.token_registrators = self.create_token_registrators(load_embeddings=True)

        pipeline = StableDiffusionXLPipeline.from_pretrained(
            self.args.pretrained_model_name_or_path,
            tokenizer=self.tokenizer_one,
            tokenizer_2=self.tokenizer_two,
            text_encoder=self.text_encoder_one,
            text_encoder_2=self.text_encoder_two,
            vae=vae,
            unet=self.unet_unziplora.unet,
            revision=self.args.revision,
            torch_dtype=self.weight_dtype,
        )

        # pipeline.unet = self.unet_unziplora.unet
        self.set_pipeline_lr_scheduler(pipeline)
        return pipeline.to(self.device)

    @property
    def output_dir(self) -> Path:
        return Path(self.args.output_dir)

    @property
    def finetuned_weights_dir(self) -> Path:
        finetuned_weights_dir = self.args.finetuned_weights_dir
        return Path(finetuned_weights_dir) if finetuned_weights_dir else None

    def create_pipeline(self, vae):
        # return create_pipeline(accelerator, args, text_encoder_one, text_encoder_two, unet, vae,
        #                        weight_dtype)
        args = self.args
        accelerator = self.accelerator

        # pipeline = StableDiffusionXLPipeline.from_pretrained(
        #     args.pretrained_model_name_or_path,
        #     vae=vae,
        #     tokenizer=self.tokenizer_one,
        #     tokenizer_2=self.tokenizer_two,
        #     text_encoder=accelerator.unwrap_model(self.text_encoder_one),
        #     text_encoder_2=accelerator.unwrap_model(self.text_encoder_two),
        #     unet=accelerator.unwrap_model(self.unet),
        #     revision=args.revision,
        #     torch_dtype=self.weight_dtype,
        # )

        pipeline = StableDiffusionXLPipeline.from_pretrained(
            args.pretrained_model_name_or_path,
            vae=vae,
            unet=self.unet_unziplora.unet,
            revision=args.revision,
            torch_dtype=self.weight_dtype,
        )

        dict1 = torch.load(r'D:\0617\MagicMix-main\unzip\3D_40\token_embeddings_1.pt')

        dict2 = torch.load(r'D:\0617\MagicMix-main\unzip\3D_40\token_embeddings_2.pt')

        pipeline.load_textual_inversion(dict1["embeddings"], token=['[C]', '[S]'], text_encoder=pipeline.text_encoder,
                                        tokenizer=pipeline.tokenizer)
        pipeline.load_textual_inversion(dict2["embeddings"], token=['[C]', '[S]'], text_encoder=pipeline.text_encoder_2,
                                        tokenizer=pipeline.tokenizer_2)


        self.set_pipeline_lr_scheduler(pipeline)
        pipeline = pipeline.to(accelerator.device)
        pipeline.set_progress_bar_config(disable=True)
        return pipeline

    # TODO Rename this here and in `load_pipeline` and `create_pipeline`
    def set_pipeline_lr_scheduler(self, pipeline):
        scheduler_args = {}
        # scheduler_config = pipeline.lr_scheduler.config
        scheduler_config = pipeline.scheduler.config
        if "variance_type" in scheduler_config:
            # variance_type = pipeline.lr_scheduler.config.variance_type
            variance_type = scheduler_config.variance_type
            if variance_type in ["learned", "learned_range"]:
                variance_type = "fixed_small"
            scheduler_args["variance_type"] = variance_type

        pipeline.scheduler = DPMSolverMultistepScheduler.from_config(
            scheduler_config, **scheduler_args
        )

    def create_generator(self):
        if self.args.seed:
         print("seed",self.args.seed)
        return (
            torch.Generator(device=self.accelerator.device).manual_seed(self.args.seed)
            if self.args.seed
            else None
        )

    def get_accelerator(self):
        accelerator = get_accelerator(self.args)
        accelerator.register_save_state_pre_hook(self.save_model_hook)
        accelerator.register_load_state_pre_hook(self.load_model_hook)
        return accelerator

    def save_model_hook(self, models, weights, output_dir):
        if self.accelerator.is_main_process:
            self.unet_unziplora.save_unziplora(self.output_dir / "unziplora.pt")

    def load_model_hook(self, models, input_dir):
        self.unet_unziplora.load_unziplora(input_dir / "unziplora.pt")

    def load_unet_unziplora(self, unziplora_weights_path=None):
        args = self.args
        unziplora_weights = None
        # # # if self.
        if unziplora_weights_path is not None:
            path = Path(unziplora_weights_path)
            # if path.exists():
            with path.open("rb") as f:
                # self.unet.load_state_dict(torch.load(f))
                unziplora_weights = torch.load(f)

        unet_unziplora = UnziploraUNet(
            unet=args.pretrained_model_name_or_path,
            accelerator=self.accelerator,
            r=args.rank,
            xformers_mem_attn=self.args.enable_xformers_memory_efficient_attention,
            p_remove=self.args.p_remove,
            unziplora_weights=unziplora_weights
        )
        # self.unet_unziplora.load_unziplora(self.finetuned_weights_dir/"unziplora.pt")
        # unet_unziplora.load_unziplora(self.finetuned_weights_dir / "unziplora.pt")

        logger.debug(f"unet_unziplora.unet: {unet_unziplora.unet}")

        return unet_unziplora

    def compute_time_ids(self):
        original_size = (self.args.resolution, self.args.resolution)
        target_size = (self.args.resolution, self.args.resolution)
        crops_coords_top_left = (
            self.args.crops_coords_top_left_h,
            self.args.crops_coords_top_left_w,
        )

        # add_time_ids = list(original_size + crops_coords_top_left + target_size)
        # add_time_ids: Tensor = torch.tensor([list(original_size + crops_coords_top_left + target_size)])
        add_time_ids = to_accelerator(torch.tensor(
            [list(original_size + crops_coords_top_left + target_size)]
        ), accelerator=self.accelerator)

        if self.args.with_prior_preservation:
            add_time_ids = torch.cat([add_time_ids, add_time_ids], dim=0).to(add_time_ids.device)

        return add_time_ids

    @property
    def weight_dtype(self):
        return get_weight_dtype(self.accelerator)

    @property
    def device(self):
        return self.accelerator.device

    @property
    def unet(self) -> UNet2DConditionModel:
        return self.unet_unziplora.unet

    @property
    def text_encoder_one(self):
        return self.text_encoders[0]

    @property
    def text_encoder_two(self):
        return self.text_encoders[1]

    @property
    def tokenizer_one(self):
        return self.tokenizers[0]

    @property
    def tokenizer_two(self):
        return self.tokenizers[1]

    def save_unziplora(self):
        # TODO: see there
        accelerator = self.accelerator
        # if self.accelerator
        accelerator.wait_for_everyone()
        if accelerator.is_main_process:
            logger.debug(f"saveing unziplora to {self.output_dir / 'unziplora.pt'}")
            self.unet_unziplora.save_unziplora(self.output_dir / "unziplora.pt")
            for i, token_registrator in enumerate(self.token_registrators, start=1):
                # torch.save(self.get_token_embeddings_path(i), token_registrator.)
                token_registrator.save_new_embeddings(self.get_token_embeddings_path(i))

    def enable_gradient_checkpointing(self):
        self.unet.enable_gradient_checkpointing()
        if self.args.train_text_encoder:
            self.text_encoder_one.gradient_checkpointing_enable()
            self.text_encoder_two.gradient_checkpointing_enable()

    def compute_text_embeddings(self, prompts: str|list[str]) -> tuple[torch.Tensor, torch.Tensor]:
        custom_instance_prompts = self.args.custom_instance_prompts
        args = self.args

        if not args.train_text_encoder:
            if not args.with_prior_preservation:
                clear_mem()

            if not custom_instance_prompts:
                prompt_embeds, unet_add_text_embeds = self._compute_text_embeddings(
                    args.instance_prompt)

                if args.with_prior_preservation:
                    # TODO: the influence the different args may be decoupled
                    (
                        class_prompt_hidden_states,
                        class_pooled_prompt_embeds,
                    ) = self._compute_text_embeddings(args.class_prompt)

                    prompt_embeds = torch.cat(
                        [prompt_embeds, class_prompt_hidden_states], dim=0
                    )
                    unet_add_text_embeds = torch.cat(
                        [unet_add_text_embeds, class_pooled_prompt_embeds], dim=0
                    )
            else:
                # prompt_embeds, unet_add_text_embeds = self._compute_text_embeddings(prompts)
                prompt_embeds, unet_add_text_embeds = self._compute_text_embeddings(prompts)

        else:
            if not custom_instance_prompts:
                tokens_one = tokenize_prompts(
                    self.tokenizer_one, self.args.instance_prompt)
                tokens_two = tokenize_prompts(
                    self.tokenizer_two, self.args.instance_prompt)
                if args.with_prior_preservation:
                    class_tokens_one = tokenize_prompts(
                        self.tokenizer_one, args.class_prompt)
                    class_tokens_two = tokenize_prompts(
                        self.tokenizer_two, args.class_prompt)
                    tokens_one = torch.cat(
                        [tokens_one, class_tokens_one], dim=0)
                    tokens_two = torch.cat(
                        [tokens_two, class_tokens_two], dim=0)

            else:
                tokens_one = tokenize_prompts(self.tokenizer_one, prompts)
                tokens_two = tokenize_prompts(self.tokenizer_two, prompts)
            # logger.debug(tokens_one)
            # logger.debug(tokens_two)
            prompt_embeds, unet_add_text_embeds = encode_prompts(
                text_encoders=self.text_encoders,
                tokenizers=self.tokenizers,
                # prompt=None,
                text_input_ids_list=[tokens_one, tokens_two],
            )

        return prompt_embeds, unet_add_text_embeds

    def _compute_text_embeddings(self, prompts: str|list[str]) -> tuple[torch.Tensor, torch.Tensor]:
        # TODO: grad enabling to trainer??
        # with torch.set_grad_enabled(use_grad):
        # with torch.no_grad():
        # embeds, pooled = encode_prompt(
        #     [self.text_encoder_one, self.text_encoder_two],
        #     [self.tokenizer_one, self.tokenizer_two],
        #     prompt
        # )
        # return embeds.to(self.accelerator.device), pooled.to(self.accelerator.device)
        prompt_embeds, pooled_prompt_embeds = encode_prompts(
            self.text_encoders, self.tokenizers, prompts
        )
        # prompt_embeds = prompt_embeds.to(self.device)
        # pooled_prompt_embeds = pooled_prompt_embeds.to(self.device)
        return prompt_embeds, pooled_prompt_embeds

        # In InferencePipeline class

    def generate(self, timesteps: torch.Tensor | int, noisy_latents: torch.Tensor = None,
                 prompts: list[str] = None) -> torch.Tensor:
        prompts = prompts or []

        # Generate noisy_latents and timesteps if None
        if noisy_latents is None:
            noisy_latents = self.rand_latents()

        if isinstance(timesteps, int):
            timesteps = self.rand_timesteps(timesteps)

        # Prepare UNet embeddings
        prompt_embeds, unet_add_text_embeds = self.compute_text_embeddings(prompts)

        time_ids = self.compute_time_ids()
        elems_to_repeat_text_embeds, elems_to_repeat_time_ids = calc_elems_to_repeat(
            self.args)

        unet_added_conditions = {
            "text_embeds": unet_add_text_embeds.repeat(
                elems_to_repeat_text_embeds, 1
            ).to(self.device),
            "time_ids": time_ids.repeat(elems_to_repeat_time_ids, 1).to(self.device),
        }

        return self.unet.forward(
            sample=noisy_latents.to(self.device),
            timestep=timesteps,
            encoder_hidden_states=prompt_embeds.to(self.device).repeat(
                elems_to_repeat_text_embeds, 1, 1
            ),
            added_cond_kwargs=unet_added_conditions,
        ).sample

    def rand_latents(self):
        return torch.randn(
            (self.args.train_batch_size, *self.latent_dims),
            device=self.device,
            dtype=self.weight_dtype,
        )

    def rand_timesteps(self, num_train_timesteps: int):
        timesteps = torch.randint(
            0, num_train_timesteps,
            (self.args.train_batch_size,),
            dtype=self.weight_dtype,
            device=self.device
        ).long()
        return timesteps

    @property
    def latent_dims(self):
        return self.vae.config.latent_channels, self.vae.config.latent_height, self.vae.config.latent_width
        # return latent_dims

    # @property
    def get_regularization_loss(self) -> torch.Tensor | Literal[0]:
        return self.unet_unziplora.get_regularization_loss()


TextEncoder = CLIPPreTrainedModel


def get_text_encoders(args, accelerator: Accelerator) -> tuple[TextEncoder, ...]:
    return tuple(get_text_encoder(args, accelerator=accelerator, subfolder=subfloder) for subfloder in
            [TEXT_ENCODER1_SUBFOLDER, TEXT_ENCODER2_SUBFOLDER])


def clear_mem():
    # del self.tokenizers, self.text_encoders
    gc.collect()
    torch.cuda.empty_cache()


def import_model_class_from_model_name_or_path(
        pretrained_model_name_or_path: str, revision: str, subfolder: str = "text_encoder"
) -> type[CLIPPreTrainedModel]:
    text_encoder_config = PretrainedConfig.from_pretrained(
        pretrained_model_name_or_path, subfolder=subfolder, revision=revision
    )
    model_class = text_encoder_config.architectures[0]

    if model_class == "CLIPTextModel":
        from transformers import CLIPTextModel

        return CLIPTextModel
    elif model_class == "CLIPTextModelWithProjection":
        from transformers import CLIPTextModelWithProjection

        return CLIPTextModelWithProjection
    else:
        raise ValueError(f"{model_class} is not supported.")


def tokenize_prompts(tokenizer: PreTrainedTokenizerBase, prompts: str|list[str]):
    logger.debug(f"Tokenizing prompt: {prompts}")
    text_inputs = tokenizer(text=prompts,
                            padding="max_length",
                            max_length=tokenizer.model_max_length,
                            truncation=True,
                            return_tensors="pt",
                            )
    text_input_ids = text_inputs.input_ids
    return text_input_ids


Tokenizer = PreTrainedTokenizerBase


def encode_prompts(text_encoders: tuple[TextEncoder, ...], tokenizers: tuple[Tokenizer, ...] | None = None, prompts: str | list[str] | None = None, text_input_ids_list: list[int] | None = None) -> \
tuple[Tensor, Tensor | None]:
    prompt_embeds_list = []

    pooled_prompt_embeds = None
    for i, text_encoder in enumerate(text_encoders):
        if text_input_ids_list is None:
            assert tokenizers is not None and prompts is not None, "tokenizers and prompts must be provided if text_input_ids_list is None"
            tokenizer = tokenizers[i]
            text_input_ids = tokenize_prompts(tokenizer, prompts)
        # if tokenizers is None:
        else:
            assert prompts is None, "prompts must be None if text_input_ids_list is not None"
            text_input_ids = text_input_ids_list[i]

        output_with_pooling = text_encoder(
            text_input_ids.to(text_encoder.device),
            output_hidden_states=True,
        )

        # We are only ALWAYS interested in the pooled _output of the final text encoder
        pooled_prompt_embeds = output_with_pooling[0]
        prompt_embeds = output_with_pooling.hidden_states[-2]
        bs_embed, seq_len, _ = prompt_embeds.shape
        pooled_prompt_embeds = None if pooled_prompt_embeds is None else pooled_prompt_embeds.view(bs_embed, -1)
        prompt_embeds = prompt_embeds.view(bs_embed, seq_len, -1)
        prompt_embeds_list.append(prompt_embeds)


    prompt_embeds: Tensor = torch.concat(prompt_embeds_list, dim=-1)
    # pooled_prompt_embeds = pooled_prompt_embeds.view(bs_embed, -1) if pooled_prompt_embeds else None
    return prompt_embeds, pooled_prompt_embeds


def get_noise_scheduler(args):
    noise_scheduler = DDPMScheduler.from_pretrained(
        args.pretrained_model_name_or_path, subfolder="scheduler"
    )
    return noise_scheduler


ImageEncoder = AutoencoderKL


def get_vae(args: Args, accelerator) -> ImageEncoder:
    vae_path = (
        args.pretrained_model_name_or_path
        if args.pretrained_vae_model_name_or_path is None
        else args.pretrained_vae_model_name_or_path
    )
    # logger.debug(f"Memory before VAE: {torch.cuda.memory_allocated() / 1024 ** 2:.0f}[MB] (out of {torch.cuda.memory_reserved() / 1024 ** 2:.0f})")
    # try:
    #     logger.debug(f"Memory before VAE: {torch.cuda.memory_summary()}")
    # except:
    #     pass

    vae = ImageEncoder.from_pretrained(
        vae_path,
        subfolder="vae" if args.pretrained_vae_model_name_or_path is None else None,
        revision=args.revision,
        # device=accelerator.device,
        # torch_dtype=torch.float32
        # torch_dtype=accelerator.device
    )
    vae.requires_grad_(False)
    vae = accelerator.prepare(vae)

    # vae.to(device=device, dtype=weight_dtype)
    # to_accelerator(vae, accelerator)
    # vae.to(dtype=torch.float32, device=accelerator.device)
    # logger.debug(f"Memory after VAE: {torch.cuda.memory_allocated() / 1024 ** 2:.0f}[MB] (out of {torch.cuda.memory_reserved() / 1024 ** 2:.0f})")
    # try:
    #     logger.debug(f"Memory after VAE: {torch.cuda.memory_summary()}")
    # except:
    #     pass
    return vae


def get_text_encoder(args, subfolder, accelerator: Accelerator):
    text_encoder_cls = import_model_class_from_model_name_or_path(
        args.pretrained_model_name_or_path, args.revision, subfolder=subfolder
    )
    text_encoder = text_encoder_cls.from_pretrained(
        args.pretrained_model_name_or_path,
        subfolder=subfolder,
        revision=args.revision,

    )
    train = args.train_text_encoder
    to_accelerator(text_encoder, accelerator, prepare=train)
    text_encoder.requires_grad_(train)
    # text_encoder.set_r(False)
    return text_encoder

    # return text_encoder_cls, text_encoder


def get_tokenizers(args: Args):
    tokenizer_one = AutoTokenizer.from_pretrained(
        args.pretrained_model_name_or_path,
        subfolder=TOKENIZER1_SUBFOLDER,
        revision=args.revision,
        use_fast=False,
    )
    tokenizer_two = AutoTokenizer.from_pretrained(
        args.pretrained_model_name_or_path,
        subfolder=TOKENIZER2_SUBFOLDER,
        revision=args.revision,
        use_fast=False,
    )
    return tokenizer_one, tokenizer_two


def generate_images(accelerator, args, epoch, text_encoder_one, text_encoder_two, unet, vae, weight_dtype):
    pipeline: StableDiffusionXLPipeline = create_pipeline(accelerator, args, text_encoder_one, text_encoder_two, unet, vae,
                               weight_dtype)
    # run inference
    generator = (
        torch.Generator(device=accelerator.device).manual_seed(args.seed)
        if args.seed
        else None
    )
    pipeline_args = {"prompt": args.validation_prompt,
                     'num_images_per_prompt': args.num_validation_images,
                     }
    if args.resolution is not None:
        pipeline_args["height"] = pipeline_args["width"] = args.resolution

    logger.debug(f"pipeline_args: {pipeline_args}")
    images = pipeline(**pipeline_args, generator=generator).images
    handle_tracking(accelerator, args, epoch, images)
    del pipeline


def handle_tracking(accelerator, args, epoch, images):
    for tracker in accelerator.trackers:
        if tracker.name == "tensorboard":
            np_images = np.stack([np.asarray(img) for img in images])
            tracker.writer.add_images(
                "validation", np_images, epoch, dataformats="NHWC"
            )
        if tracker.name == "wandb":
            tracker.log(
                {
                    "validation": [
                        wandb.Image(
                            image, caption=f"{i}: {args.validation_prompt}"
                        )
                        for i, image in enumerate(images)
                    ]
                }
            )


def create_pipeline(accelerator, args, text_encoder_one, text_encoder_two, unet, vae, weight_dtype):
    pipeline = StableDiffusionXLPipeline.from_pretrained(
        args.pretrained_model_name_or_path,
        vae=vae,
        text_encoder=accelerator.unwrap_model(text_encoder_one),
        text_encoder_2=accelerator.unwrap_model(text_encoder_two),
        unet=accelerator.unwrap_model(unet),
        revision=args.revision,
        torch_dtype=weight_dtype,
    )
    # We train on the simplified learning objective. If we were previously predicting a variance, we need the scheduler to ignore it
    scheduler_args = {}
    # scheduler_config = pipeline.lr_scheduler.config
    scheduler_config = pipeline.scheduler.config
    if "variance_type" in scheduler_config:
        variance_type = scheduler_config.variance_type
    # if "variance_type" in pipeline.lr_scheduler.config:
    #     variance_type = pipeline.lr_scheduler.config.variance_type

        if variance_type in ["learned", "learned_range"]:
            variance_type = "fixed_small"

        scheduler_args["variance_type"] = variance_type
    # pipeline.lr_scheduler = DPMSolverMultistepScheduler.from_config(
    pipeline.scheduler = DPMSolverMultistepScheduler.from_config(
        scheduler_config, **scheduler_args
    )
    pipeline = pipeline.to(accelerator.device)
    pipeline.set_progress_bar_config(disable=True)
    return pipeline


def create_model_input(args, pixel_values, vae, weight_dtype):
    model_input = vae.encode(pixel_values.to(device=vae.device, dtype=vae.dtype)).latent_dist.sample()
    model_input = model_input * vae.config.scaling_factor
    if args.pretrained_vae_model_name_or_path is None:
        model_input = model_input.to(weight_dtype)
    return model_input


TEXT_ENCODER1_SUBFOLDER = "text_encoder"
TEXT_ENCODER2_SUBFOLDER = "text_encoder_2"
TOKENIZER2_SUBFOLDER = "tokenizer_2"
TOKENIZER1_SUBFOLDER = "tokenizer"


def calc_elems_to_repeat(args):
    bsz, custom_instance_prompts = args.train_batch_size, args.custom_instance_prompts
    if not custom_instance_prompts:
        elems_to_repeat_text_embeds = (
            bsz // 2 if args.with_prior_preservation else bsz
        )
        elems_to_repeat_time_ids = (
            bsz // 2 if args.with_prior_preservation else bsz
        )
    else:
        elems_to_repeat_text_embeds = 1
        elems_to_repeat_time_ids = (
            bsz // 2 if args.with_prior_preservation else bsz
        )
    return elems_to_repeat_text_embeds, elems_to_repeat_time_ids
