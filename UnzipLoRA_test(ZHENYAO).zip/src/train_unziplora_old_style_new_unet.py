#!/usr/bin/env python
# coding=utf-8
# Copyright 2023 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
import logging

from diffusers.utils import check_min_version
# from pyarrow import Tensor
from torch import Tensor
from torch.nn import Module
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LRScheduler
from torch.utils.data import DataLoader

from logger import logger

# Tokenizer: TypeAlias = AutoTokenizer


# Will error if the minimal version of diffusers is not installed. Remove at your own risks.
check_min_version("0.24.0.dev0")

# import logging
# import sys

# Create a logger
logger.setLevel(logging.DEBUG)  # Set the logging level

# # Create a StreamHandler for stdout
# stdout_handler = logging.StreamHandler(sys.stdout)
# stdout_handler.setLevel(logging.DEBUG)  # Set the handler's logging level

# # Create a formatter and attach it to the handler
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# stdout_handler.setFormatter(formatter)

# # Add the handler to the logger
# logger.addHandler(stdout_handler)


def text_encoder_lora_state_dict(text_encoder):
    state_dict = {}

    def text_encoder_attn_modules(text_encoder):
        from transformers import CLIPTextModel, CLIPTextModelWithProjection

        attn_modules = []

        if isinstance(text_encoder, (CLIPTextModel, CLIPTextModelWithProjection)):
            for i, layer in enumerate(text_encoder.text_model.encoder.layers):
                name = f"text_model.encoder.layers.{i}.self_attn"
                mod = layer.self_attn
                attn_modules.append((name, mod))

        return attn_modules

    for name, module in text_encoder_attn_modules(text_encoder):
        for k, v in module.q_proj.lora_linear_layer.state_dict().items():
            state_dict[f"{name}.q_proj.lora_linear_layer.{k}"] = v

        for k, v in module.k_proj.lora_linear_layer.state_dict().items():
            state_dict[f"{name}.k_proj.lora_linear_layer.{k}"] = v

        for k, v in module.v_proj.lora_linear_layer.state_dict().items():
            state_dict[f"{name}.v_proj.lora_linear_layer.{k}"] = v

        for k, v in module.out_proj.lora_linear_layer.state_dict().items():
            state_dict[f"{name}.out_proj.lora_linear_layer.{k}"] = v

    return state_dict


# Adapted from pipelines.StableDiffusionXLPipeline.encode_prompt


# def is_belong_to_groups(key: str, groups: list) -> bool:
#     try:
#         for g in groups:
#             if key.startswith(g):
#                 return True
#         return False
#     except Exception as e:
#         raise type(e)(f'failed to is_belong_to_groups, due to: {e}')


# def filter_lora_layers(lora_state_dict: dict, groups: list) -> dict:
#     try:
#         return {k: v for k, v in lora_state_dict.items() if is_belong_to_groups(k, groups)}
#     except Exception as e:
#         raise type(e)(f'failed to filter_lora_layers, due to: {e}')



from typing import Union, TypeAlias

TorchObject: TypeAlias = Union[Module, Tensor, DataLoader, Optimizer, LRScheduler]

# type TorchObject = Module | Tensor | DataLoader | Optimizer | LRScheduler


# def register_load_state_pre_hook(accelerator):
#     def load_model_hook(models, input_dir):
#         unet_ = None
#         text_encoder_one_ = None
#         text_encoder_two_ = None
# 
#         while len(models) > 0:
#             model = models.pop()
# 
#             # TODO: get those from outside
#             if isinstance(model, type(accelerator.unwrap_model(unet))):
#                 unet_ = model
#             elif isinstance(model, type(accelerator.unwrap_model(text_encoder_one))):
#                 text_encoder_one_ = model
#             elif isinstance(model, type(accelerator.unwrap_model(text_encoder_two))):
#                 text_encoder_two_ = model
#             else:
#                 raise ValueError(f"unexpected save model: {model.__class__}")
# 
#         # TODO
#         lora_state_dict, network_alphas = LoraLoaderMixin.lora_state_dict(
#             input_dir)
#         LoraLoaderMixin.load_lora_into_unet(
#             lora_state_dict, network_alphas=network_alphas, unet=unet_
#         )
# 
#         text_encoder_state_dict = {
#             k: v for k, v in lora_state_dict.items() if "text_encoder." in k
#         }
#         LoraLoaderMixin.load_lora_into_text_encoder(
#             text_encoder_state_dict,
#             network_alphas=network_alphas,
#             text_encoder=text_encoder_one_,
#         )
# 
#         text_encoder_2_state_dict = {
#             k: v for k, v in lora_state_dict.items() if "text_encoder_2." in k
#         }
#         LoraLoaderMixin.load_lora_into_text_encoder(
#             text_encoder_2_state_dict,
#             network_alphas=network_alphas,
#             text_encoder=text_encoder_two_,
#         )
# 
#     # accelerator.register_save_state_pre_hook(save_model_hook)
#     accelerator.register_load_state_pre_hook(load_model_hook)
# 
# 
# def register_save_state_pre_hook(accelerator):
#     def save_model_hook(models, weights, output_dir):
#         if accelerator.is_main_process:
#             # there are only two options here. Either are just the unet attn processor layers
#             # or there are the unet and text encoder atten layers
#             unet_lora_layers_to_save = None
#             text_encoder_one_lora_layers_to_save = None
#             text_encoder_two_lora_layers_to_save = None
# 
#             for model in models:
#                 if isinstance(model, type(accelerator.unwrap_model(unet))):
#                     unet_lora_layers_to_save = unet_lora_state_dict(
#                         model)  # TODO
#                 elif isinstance(
#                         model, type(accelerator.unwrap_model(text_encoder_one))
#                 ):
#                     text_encoder_one_lora_layers_to_save = text_encoder_lora_state_dict(
#                         model
#                     )
#                 elif isinstance(
#                         model, type(accelerator.unwrap_model(text_encoder_two))
#                 ):
#                     text_encoder_two_lora_layers_to_save = text_encoder_lora_state_dict(
#                         model
#                     )
#                 else:
#                     raise ValueError(f"unexpected save model: {
#                                      model.__class__}")
# 
#                 # make sure to pop weight so that corresponding model is not saved again
#                 weights.pop()
# 
#             StableDiffusionXLPipeline.save_lora_weights(
#                 output_dir,
#                 unet_lora_layers=unet_lora_layers_to_save,
#                 text_encoder_lora_layers=text_encoder_one_lora_layers_to_save,
#                 text_encoder_2_lora_layers=text_encoder_two_lora_layers_to_save,
#             )
# 
#     accelerator.register_save_state_pre_hook(save_model_hook)


# if __name__ == "__main__":
#     args = parse_args()
#     main(args)
