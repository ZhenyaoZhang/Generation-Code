from pathlib import Path

import torch
from dotenv import load_dotenv

from train_unziplora import parse_args
from unziplora_inference import UnziploraInference, get_vae


def main(args):
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    # with torch.no_grad
    with torch.no_grad():
        inference_pipeline = UnziploraInference(args)

        vae = get_vae(args, inference_pipeline.accelerator)
        images = inference_pipeline.generate_images(vae, reload_pipeline=False)

    for i, image in enumerate(images):
        image.save(Path(args.output_dir) / f"{i}.png")

if __name__ == '__main__':
    load_dotenv()
    args = parse_args()
    main(args)
