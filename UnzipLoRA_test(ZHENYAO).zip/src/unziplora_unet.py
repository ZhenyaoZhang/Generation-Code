import funcy
import random
from pathlib import Path
from typing import Literal

import torch
from accelerate import Accelerator
from diffusers import UNet2DConditionModel
from torch import nn

from logger import logger
from acceleration import to_accelerator
from _not_maintained import enable_xformer_memory_efficient_attention
from unziplora import UnziploraLinear


class UnziploraUNet:
    """
    A class to wrap a UNet2DConditionModel with UnzipLoRA.
    """
    def __init__(self, r: int, unet: UNet2DConditionModel | str | Path,
                 unziplora_weights: dict[str, torch.Tensor] = None, accelerator: Accelerator = None,
                 xformers_mem_attn: bool = False, p_remove: float = 0.):
        # super().__init__(r)
        # self.use_xformers_mem_attention = enable_xformers_memory_efficient_attention
        self.r = r
        self.accelerator = accelerator
        # self.vae = vae

        match unet:
            case UNet2DConditionModel():
                unet = unet.copy()
            case str() | Path():
                device = "cpu" if p_remove else self.accelerator.device
                print(f"{unet}(remove:{p_remove}):{device}")
                unet = UNet2DConditionModel.from_pretrained(
                    unet, accelerator=accelerator, subfolder="unet", device=device
                    )
            case _:
                raise ValueError(f"Invalid unet: {unet}")
        self.removed_blocks = None
        if p_remove:
            self.removed_blocks = drop_random_blocks(unet, p_remove)
            unet = unet.to(self.accelerator.device)

        self.unet: UNet2DConditionModel = unet
        # self.unet.register_full_backward_pre_hook(print)
        # UNet2DConditionModel.backward
        # self.unet.register_full_backward_pre_hook(lambda model, grad: print(f"{type(model)}.backward: grad.norm={grad[0].norm()}"))
        self.unet.register_full_backward_pre_hook(
            lambda model, grad: None)
        # self.unet = unet.copy() if unet else UNet2DConditionModel()
        # self.unet.requires_grad_(False)
        if self.accelerator:
            to_accelerator(x=unet, accelerator=accelerator)

        if xformers_mem_attn:
            enable_xformer_memory_efficient_attention(self.unet)
            # self.unet = self.accelerator.prepare(self.unet)
            # unet.to(self.accelerator.device, )

        self.__original_layers: dict[str, nn.Linear] | None = None
        self.__unziplora_layers: dict[str, UnziploraLinear] | None = None
        self.__unziplora_weights = {w_name:w for (w_name, w) in unziplora_weights.items() if "lora" in w_name} if unziplora_weights else None

        # self.wrappers: dict[str, nn.Module] = {}
        self.activate_unziplora()
        # self.__call__ = self.unet.__call__


    def load_unziplora(self, path):
        if self.__unziplora_layers:
            del self.__unziplora_layers
            self.__unziplora_layers = None

        with Path(path).open("rb") as f:
            # self.unet.load_state_dict(torch.load(f))
            self.__unziplora_weights = {w_name: w for (w_name, w) in torch.load(f).items()}

        self.activate_unziplora()
        # with Path(path).open("rb") as f:
        #     self.unet.load_state_dict(torch.load(f))
        # self.activate_unziplora()

    # @classmethod
    # def from_pretrained(cls, pretrained_unet_name_or_path: str, **kwargs):
    #     # unet: UNet2DConditionModel = UNet2DConditionModel.from_pretrained(pretrained_unet_name_or_path, subfolder=subfolder, revision=revision, accelerator=accelerator)
    #     unet: UNet2DConditionModel = UNet2DConditionModel.from_pretrained(
    #         pretrained_unet_name_or_path,
    #         subfolder=kwargs.pop("subfolder", "unet"), revision=revision, accelerator=accelerator)
    #     return cls(r, unet=unet, accelerator=accelerator)

    def activate_unziplora(self):
        for name, module in self.unziplora_layers.items():
            logger.debug(f"Activate unziplora: {name}")
            self.unet.set_submodule(name, module.to(self.unet.device))

    def deactivate_unziplora(self):
        for name, module in self.original_layers.items():
            logger.debug(f"Deactivate unziplora: {name}")
            self.unet.set_submodule(name, module)

    @property
    def original_layers(self) -> dict[str, nn.Linear]:
        if self.__original_layers is None:
            self.__original_layers = {name: module for name, module in self.unet.named_modules() if
                                      self.should_wrap(name, module)}
            logger.debug(f"Found {len(self.__original_layers)} layers")

        return self.__original_layers

    @property
    def unziplora_layers(self) -> dict[str, UnziploraLinear]:
        if self.__unziplora_layers is None:
            # self.__unziplora_layers = dict(funcy.walk_values(self.wrap,self.original_layers))
            # self.__unziplora_layers = dict(funcy.walk(self.wrap,self.original_layers))
            # logger.debug(f"Unziplora: wrap {len(self.original_layers)} layers: {str(list(self.__original_layers.keys()))[:1000]}")
            self.__unziplora_layers = {name: self.wrap(module, name=name) for name, module in
                                       self.original_layers.items()}
            logger.debug(f"Unziplora: wrapped {len(self.__unziplora_layers)} layers")

        return self.__unziplora_layers

    def wrap(self, module: nn.Linear, name: str = None) -> UnziploraLinear:
        logger.debug(f"wrap {name}")
        res = UnziploraLinear(module, self.r)
        # if name and self.__unziplora_weights:
        if name and self.__unziplora_weights: # TODO: something is wrong here?
            # logger.debug(f"wrap {name}")

            prefix = f"{name}."
            # res.state
            # new_weights = {w_name.removeprefix(prefix): w for w_name, w in self.__unziplora_weights.items() if
            new_weights = {w_name.removeprefix(prefix): w for w_name, w in self.__unziplora_weights.items() if
                                 w_name.startswith(prefix)}
            # res.load_state_dict()
            # logger
            new_weights.update({".".join(("linear", n)): w for n, w in module.state_dict().items()})
            res.state_dict(destination=new_weights)#.update(new_weights)

        return res

    @property
    def unziplora_weights(self) -> dict[str, torch.Tensor]:
        if self.__unziplora_weights is None:
            self.__unziplora_weights = {".".join((name, w_name)): w for name, layer in self.unziplora_layers.items() for w_name, w in
                layer.unziplora_weights.items()}
            # self.__unziplora_weights = {".".join((name, w_name)): w for name, layer in self.unziplora_layers.items() for w_name, w in
            #     layer.state_dict().items() if "lora" in w_name} #TODO: something is wrong here?

        return self.__unziplora_weights
        # return {".".join((name, w_name)): w for name, layer in self.unziplora_layers.items() for w_name, w in
        #         layer.state_dict().items()}

    def should_wrap(self, name: str, module: nn.Module) -> bool:
        return isinstance(module, nn.Linear) and (name.endswith('.to_k') or name.endswith('.to_v'))

    def save_unziplora(self, path: Path):
        with path.open("wb") as f:
            # torch.save(self.unziplora_layers, f)
            torch.save(self.unziplora_weights, f)

    def get_regularization_loss(self) -> torch.Tensor | Literal[0]:
        return torch.stack(
            [
                layer.get_regularization_loss()
                for layer in self.unziplora_layers.values()
            ]
        ).mean()
        # safetensors.torch.save_file(weights, path, metadata={"format": "pt"})


def drop_random_blocks(unet, p_remove)->list[int]:
    total_blocks = 0
    # total_removed = 0
    removed_indices = []
    for name, transformer_blocks in unet.named_modules():
    # print(name, type(module).__name__)
        if not name.endswith(".transformer_blocks"):
            continue
        transformer_blocks: nn.ModuleList
        n_blocks = len(transformer_blocks)
        total_blocks += n_blocks
        # print(n_blocks)
        if n_blocks<=2:
            # print(transformer_blocks)
            continue
        for i in reversed(range(n_blocks)):
            # print(i)
            if random.random()<p_remove:

                # block = transformer_blocks.pop(i)
                block = transformer_blocks[i]
                transformer_blocks[i] = IdentityBlock()

                # print("remove", block)
                # block.cpu()
                del block
                # total_removed += 1
                removed_indices.append(i)
    total_removed = len(removed_indices)
    logger.debug(f"removed {total_removed} out of {total_blocks} blocks")
    return removed_indices


class IdentityBlock(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, *args, **kwargs) -> torch.Tensor:
        return kwargs.get("hidden_states", False) or args[0]
