import torch
from accelerate import Accelerator
from torch import Tensor

from _not_maintained import get_prodigy_optimizer
from common_typing import Args
from logger import logger
from acceleration import to_accelerator


def get_optimization_params(accelerator, args, text_lora_parameters_one, text_lora_parameters_two,
                            unet_lora_parameters):
    if args.allow_tf32:
        torch.backends.cuda.matmul.allow_tf32 = True
    if args.scale_lr:
        scale_lr(accelerator, args)
    # Optimization parameters
    unet_lora_parameters_with_lr = {
        "params": unet_lora_parameters,
        "lr": args.learning_rate,
    }
    if args.train_text_encoder:
        # different learning rate for text encoder and unet
        text_lora_parameters_one_with_lr = {
            "params": text_lora_parameters_one,
            "weight_decay": args.adam_weight_decay_text_encoder,
            "lr": args.text_encoder_lr or args.learning_rate,
        }
        text_lora_parameters_two_with_lr = {
            "params": text_lora_parameters_two,
            "weight_decay": args.adam_weight_decay_text_encoder,
            "lr": args.text_encoder_lr or args.learning_rate,
        }
        params_to_optimize = [
            unet_lora_parameters_with_lr,
            text_lora_parameters_one_with_lr,
            text_lora_parameters_two_with_lr,
        ]
    else:
        params_to_optimize = [unet_lora_parameters_with_lr]
    return params_to_optimize


def create_optimizer(args: Args, params_to_optimize: list[Tensor], accelerator: Accelerator=None):
    if not (args.optimizer.lower() == "prodigy" or args.optimizer.lower() == "adamw"):
        logger.warn(
            f"Unsupported choice of optimizer: {args.optimizer}.Supported optimizers include [adamW, prodigy]."
            "Defaulting to adamW"
        )
        args.optimizer = "adamw"
    if args.use_8bit_adam and not args.optimizer.lower() == "adamw":
        logger.warn(
            f"use_8bit_adam is ignored when optimizer is not set to 'AdamW'. Optimizer was "
            f"set to {args.optimizer.lower()}"
        )

    match args.optimizer.lower():
        case "adamw":
    # if args.optimizer.lower() == "adamw":
            optimizer = get_adamw_optimizer(args, params_to_optimize)
        case "prodigy":
    # elif args.optimizer.lower() == "prodigy":
            optimizer = get_prodigy_optimizer(args, params_to_optimize)
        case _:
            raise AssertionError("Unsupported optimizer choice should have been caught earlier and set to adamw.")

    return optimizer if accelerator is None else to_accelerator(optimizer, accelerator)


def get_adamw_optimizer(args, params_to_optimize):
    if args.use_8bit_adam:
        try:
            import bitsandbytes as bnb
        except ImportError:
            raise ImportError(
                "To use 8-bit Adam, please install the bitsandbytes library: `pip install bitsandbytes`."
            )

        optimizer_class = bnb.optim.AdamW8bit
    else:
        optimizer_class = torch.optim.AdamW

    optimizer = optimizer_class(
        params_to_optimize,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )
    return optimizer


def scale_lr(accelerator, args):
    args.learning_rate = (
        args.learning_rate
        * args.gradient_accumulation_steps
        * args.train_batch_size
        * accelerator.num_processes
    )
