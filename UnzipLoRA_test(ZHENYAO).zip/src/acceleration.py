import logging
from pathlib import Path

import diffusers
import transformers
from accelerate import DistributedDataParallelKwargs, Accelerator
from accelerate.utils import ProjectConfiguration
from torch import Tensor

from logger import logger
from train_unziplora_old_style_new_unet import TorchObject


def set_loggers(accelerator):
    # Make one log on every process with the configuration for debugging.
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )
    if accelerator.is_local_main_process:
        transformers.utils.logging.set_verbosity_warning()
        diffusers.utils.logging.set_verbosity_info()
    else:
        transformers.utils.logging.set_verbosity_error()
        diffusers.utils.logging.set_verbosity_error()


# TODO: make it possible to run without accelerator; other stuff to simplify away?
def get_accelerator(args):
    logging_dir = Path(args.output_dir, args.logging_dir)
    accelerator_project_config = ProjectConfiguration(
        project_dir=args.output_dir, logging_dir=str(logging_dir)
    )
    distributed_data_parallel_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
    # data_loader_config_kwargs = DataLoaderConfiguration()
    accelerator = Accelerator(
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        mixed_precision=args.mixed_precision,
        log_with=args.report_to,
        project_config=accelerator_project_config,
        kwargs_handlers=[distributed_data_parallel_kwargs],

        # num_processes=1,

    )
    # accelerator.dataloader_config
    # logger.info(accelerator.state, main_process_only=False)
    logger.info(accelerator.state)
    set_loggers(accelerator)
    if accelerator.is_main_process:
        accelerator.init_trackers("dreambooth-lora-sd-xl", config=dict(vars(args)))
    # accelerator
    return accelerator

from typing import TypeVar

T = TypeVar('T', bound='TorchObject')  # 定义类型变量 T，约束为 TorchObject 类或其子类
def to_accelerator(x: T, accelerator: Accelerator, prepare: object = True) -> T:
    logger.debug(f"Moving a {type(x).__name__} to {accelerator.device}")
    # logger.debug(f"Memory before: {torch.cuda.memory_allocated() / 1024 ** 2:.0f}[MB] (out of {torch.cuda.memory_reserved() / 1024 ** 2:.0f})")
    # try:
    #     logger.debug(f"Memory before: {torch.cuda.memory_summary()}")
    # except:
    #     pass
    # weight_dtype = get_weight_dtype(accelerator)

    # if isinstance(x, Module|Tensor) and (x.dtype != weight_dtype or x.device != accelerator.device) and not (os.getenv("LOCAL_TEST", "false").lower()=="true"):
    #     x.to(accelerator.device, dtype=weight_dtype)
    if prepare and not isinstance(x, Tensor):
        x = accelerator.prepare(x)

    # logger.debug(f"Memory after: {torch.cuda.memory_allocated() / 1024 ** 2:.0f}[MB] (out of {torch.cuda.memory_reserved() / 1024 ** 2:.0f})")
    # try:
    #    logger.debug(f"Memory after: {torch.cuda.memory_summary()}")
    # except:
    #     pass
    return x
