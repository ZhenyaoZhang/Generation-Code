import argparse
import math
import os
import shutil
from pathlib import Path
from typing import Iterable

import PIL
import numpy as np
import torch
from accelerate.utils import set_seed
from diffusers import get_scheduler
from diffusers.training_utils import compute_snr
from torch import Tensor
from torch.nn import functional as F
from torch.optim.lr_scheduler import LRScheduler
from torch.utils.data import DataLoader
from tqdm import tqdm

from common_typing import Args
from optimization import create_optimizer
from utils import set_seed_by_args
from _not_maintained import prior_preservation_generate_class_images
from data import ImagePromptRecord, ImagePromptBatch, create_dataloader, create_dataset
from unziplora_inference import UnziploraInference, get_noise_scheduler, create_model_input
from logger import logger
from acceleration import to_accelerator


# SIMPLIFIED = False

class UnziploraTrainer:
    def __init__(self, args: Args, inference_pipeline: UnziploraInference) -> None:
        self.args = args
        self.inference_pipeline = inference_pipeline

        self.seed = set_seed_by_args(args)

        if args.with_prior_preservation:
            prior_preservation_generate_class_images(self.accelerator, args)

        self.noise_scheduler = get_noise_scheduler(args)
        # self.vae = get_vae(self.args, accelerator=self.accelerator)

        self.train_dataset = create_dataset(self.args)
        self.dataloader: DataLoader[ImagePromptRecord] = create_dataloader(
            self.args, self.train_dataset, accelerator=self.accelerator)

        self.optimizer = create_optimizer(
            self.args, self.params_for_training, accelerator=self.accelerator)

        if args.max_train_steps is None:
            args.max_train_steps = args.num_train_epochs * self.num_update_steps_per_epoch

        args.num_train_epochs = math.ceil(
            args.max_train_steps / self.num_update_steps_per_epoch)

        self.lr_scheduler = create_lr_scheduler(
            self.accelerator, self.args, self.optimizer)

        self.first_epoch = 0
        self.global_step = 0

        checkpoint_path = None
        resume_from_checkpoint = args.resume_from_checkpoint
        if resume_from_checkpoint == "latest":
            # Get the mos recent checkpoint
            dirs = os.listdir(args.output_dir)
            dirs = [d for d in dirs if d.startswith("checkpoint")]
            dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
            if len(dirs) > 0:
                checkpoint_path = dirs[-1]
            else:
                self.accelerator.print(
                    f"Checkpoint '{resume_from_checkpoint}' does not exist. Starting a new training run."
                )
        elif resume_from_checkpoint:
            checkpoint_path = os.path.basename(resume_from_checkpoint)
        self.checkpoint_path = checkpoint_path
        if self.checkpoint_path is None:
            args.resume_from_checkpoint = None
            # initial_global_step = 0

        self.progress_bar = None

    @property
    def output_dir(self):
        return Path(self.args.output_dir)

    # def resume_from_checkpoint(self):
    #     self.first_epoch, self.global_step = resume_from_checkpoint(self.accelerator, self.args,
    #                                                                 self.num_update_steps_per_epoch)
    def resume_from_checkpoint(self):
        # if args.resume_from_checkpoint != "latest":
        #     path = os.path.basename(args.resume_from_checkpoint)
        # else:
        #     # Get the mos recent checkpoint
        #     dirs = os.listdir(args.output_dir)
        #     dirs = [d for d in dirs if d.startswith("checkpoint")]
        #     dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
        #     path = dirs[-1] if len(dirs) > 0 else None
        path = self.checkpoint_path
        args = self.args
        if path is None:
            self.accelerator.print(
                f"Checkpoint '{args.resume_from_checkpoint}' does not exist. Starting a new training run."
            )
            args.resume_from_checkpoint = None
            return

        self.accelerator.print(f"Resuming from checkpoint {path}")
        # self.accelerator.load_state(os.path.join(args.output_dir, path))
        # self.accelerator.load_state(self.output_dir / path)
        self.accelerator.load_state(path)
        global_step = int(path.split("-")[1])

        first_epoch = global_step // self.args.num_update_steps_per_epoch
        self.first_epoch, self.global_step = first_epoch, global_step

    @property
    def num_update_steps_per_epoch(self):
        return math.ceil(
            len(self.dataloader) / self.args.gradient_accumulation_steps
        )

    def train(self) -> UnziploraInference:
        self.prepare_for_training()
        # num_epochs = self.args.num_train_epochs

        try:
            for epoch in range(self.first_epoch, self.args.num_train_epochs):
                self.train_one_epoch(epoch)
        except KeyboardInterrupt:
            logger.warning("Training was interrupted.")

        self.inference_pipeline.save_unziplora()

        self.validate()

        return self.inference_pipeline

    def prepare_for_training(self):
        if self.args.gradient_checkpointing:
            self.inference_pipeline.enable_gradient_checkpointing()
        total_batch_size = get_total_batch_size(self.accelerator, self.args)
        log_start_training(self.args, total_batch_size,
                           self.dataloader, self.train_dataset)
        if self.args.resume_from_checkpoint:
            self.resume_from_checkpoint()
        self.progress_bar = tqdm(
            range(self.args.max_train_steps),
            initial=self.global_step,
            desc="Steps",
            # Only show the progress bar once on each machine.
            disable=not self.accelerator.is_local_main_process,
        )
        for x in self.params_for_training:
            x.requires_grad_(True)

        # assert all(x.requires_grad for x in self.params_for_training), "A param without grad requirement was found."
        logger.debug(f"params_for_training: {[x.shape for x in self.params_for_training]}")

    def track_images(self, images: Iterable[PIL.Image.Image], epoch=None):
        accelerator, args = self.accelerator, self.args
        images = list(images)

        for tracker in accelerator.trackers:
            if tracker.name == "tensorboard":
                np_images = np.stack([np.asarray(img) for img in images])
                tracker.writer.add_images(
                    "validation", np_images, epoch, dataformats="NHWC"
                )
            if tracker.name == "wandb":
                tracker.log(
                    {
                        "validation": [
                            self.wandb.Image(
                                image, caption=f"{i}: {args.validation_prompt}"
                            )
                            for i, image in enumerate(images)
                        ]
                    }
                )

    def save_images(self, images: list[PIL.Image.Image], subdir: str = None):
        logger.debug(f"saving {len(images)} validation images")
        for i, image in enumerate(images):
            d = self.output_dir
            if subdir is not None:
                d /= str(subdir)
                d.mkdir(parents=True, exist_ok=True)
            path = str(d / f"{i}.png")
            logger.debug(f"save {path}")
            image.save(path)

    def train_one_epoch(self, epoch: int) -> None:
        for step, batch in enumerate(self.dataloader):
            batch: ImagePromptBatch
            self.handle_training_step(step, batch)

        if is_validation_epoch(self.args, epoch=None):
            self.validate(epoch)

    def validate(self, epoch: int = None):
        log_start_validation(self.args)
        # images = self.inference_pipeline.validate(vae=self.vae, epoch=epoch)
        with torch.no_grad():
            images = self.inference_pipeline.generate_images(vae=self.vae, reload_pipeline=(epoch is None))
        self.track_images(images, epoch)
        self.save_images(images, subdir=epoch)
        set_seed((self.args.seed or 0)+(epoch or 0))


    def handle_training_step(self, step: int, batch: ImagePromptBatch) -> None:
        """
        Handles a single training step, deferring forward pass to InferencePipeline.

        Args:
            step (int): Current training step in epoch.
            batch (dict): Batch of data from the DataLoader.
        """
        # accelerator = self.accelerator
        # unet = self.inference_pipeline.unet_unziplora

        # Supports gradient accumulation if needed
        # with self.accelerator.accumulate(self.inference_pipeline.unet_unziplora.unet):
        with self.accelerator.accumulate(*(self.inference_pipeline.unet_unziplora.unziplora_layers.values())):
            # Move batch data to device
            prompts = batch["prompts"]
            pixel_values = batch["pixel_values"].to(
                dtype=self.inference_pipeline.vae.dtype, device=self.accelerator.device
            )
            noisy_latents, target, timesteps = self.preprocess_pixels(pixel_values)

            # Use InferencePipeline to compute predictions
            model_pred = self.inference_pipeline.generate(
                timesteps=timesteps, noisy_latents=noisy_latents, prompts=prompts)

            # Compute loss
            loss = self.compute_loss(model_pred, target, timesteps=timesteps)

            self.backward(loss)

            # copy_before = [x.clone().detach().requires_grad_(False) for x in self.params_for_training]
            self.optimizer.step()

            # params_change_norm = sum((x-y).norm()**2 if x.shape==y.shape else (print(f"{x.shape} != {y.shape}") or 0) for x, y in zip(self.params_for_training, copy_before))**0.5
            # logger.debug(
            #     f"params change norm: {params_change_norm}"
            # )
            # for x in copy_before:
            #     x.cpu()
            #     del x
            # del copy_before

            self.lr_scheduler.step()
            self.optimizer.zero_grad()
            # torch.

        # Increment global step and log progress
        if self.accelerator.sync_gradients:
            self.progress_bar.update(1)
            self.global_step += 1

            if self.is_checkpoint_step():
                self.handle_checkpoint()

        self.log_training_step(loss)

    def handle_checkpoint(self):
        # _before_ saving state, check if this save would set us over the `checkpoints_total_limit`
        args = self.args
        accelerator = self.accelerator

        if args.checkpoints_total_limit is not None:
            checkpoints = os.listdir(args.output_dir)
            checkpoints = [
                d for d in checkpoints if d.startswith("checkpoint")
            ]
            checkpoints = sorted(
                checkpoints, key=lambda x: int(x.split("-")[1])
            )

            # before we save the new checkpoint, we need to have at _most_ `checkpoints_total_limit - 1` checkpoints
            if len(checkpoints) >= args.checkpoints_total_limit:
                num_to_remove = (
                        len(checkpoints) - args.checkpoints_total_limit + 1
                )
                removing_checkpoints = checkpoints[0:num_to_remove]

                logger.info(
                    f"{len(checkpoints)} checkpoints already exist, removing {len(removing_checkpoints)} checkpoints"
                )
                logger.info(
                    f"removing checkpoints: {', '.join(removing_checkpoints)}"
                )

                for removing_checkpoint in removing_checkpoints:
                    removing_checkpoint = os.path.join(
                        args.output_dir, removing_checkpoint
                    )
                    shutil.rmtree(removing_checkpoint)
        save_path = os.path.join(
            args.output_dir, f"checkpoint-{self.global_step}"
        )
        accelerator.save_state(save_path)
        logger.info(f"Saved state to {save_path}")

    def is_checkpoint_step(self):
        return self.accelerator.is_main_process and self.global_step % self.args.checkpointing_steps == 0

    def log_training_step(self, loss):
        logs = {"loss": loss.item(), "lr": self.lr_scheduler.get_last_lr()[0]}
        self.progress_bar.set_postfix(**logs)
        self.accelerator.log(logs, step=self.global_step)

    def preprocess_pixels(self, pixel_values: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # Convert images to latent space
        latents = self._encode_latents(pixel_values)
        # Generate noise
        noise = torch.randn_like(latents)
        # Randomize timesteps if not provided
        timesteps = torch.randint(
            0,
            self.num_train_steps,
            (latents.size(0),),
            device=self.accelerator.device,
        ).long()
        # Add noise to latents (forward diffusion process)
        noisy_latents = self.noise_scheduler.add_noise(latents, noise, timesteps)
        target = get_prediction_target(
            latents=latents, noise=noise, noise_scheduler=self.noise_scheduler, timesteps=timesteps
        )
        return noisy_latents, target, timesteps

    @property
    def num_train_steps(self):
        return self.noise_scheduler.config.num_train_timesteps

    def backward(self, loss: Tensor):
        accelerator = self.accelerator
        # accelerator.backward(loss)  # Backprop loss
        try:
            assert all(x.requires_grad for x in self.params_for_training), "A param without grad requirement was found."
        except AssertionError:
            for x in self.params_for_training:
                logger.warning(">>> setting requires_grad in the middle of training <<<")
                x.requires_grad_(True)
        loss.backward()

        # logger.debug(f"grad norm: {sum(x.grad.norm()**2 for x in self.params_for_training)**0.5}")
        for x in self.params_for_training:
            try:
                logger.debug(f"grad norm: {x.grad.norm()}")
            except AttributeError:
                pass
                # logger.error(f"x.grad is None: {x.shape}")
                # logger.error(f"x.shape: {x.shape}; x.grad: {x.grad}; x.requires_grad: {x.requires_grad}")
        # Gradient clipping and optimizer step
        if accelerator.sync_gradients and self.args.max_grad_norm:
            accelerator.clip_grad_norm_(
                self.params_for_training, self.args.max_grad_norm)

        # return accelerator

    @property
    def accelerator(self):
        return self.inference_pipeline.accelerator

    @property
    def vae(self):
        return self.inference_pipeline.vae

    def is_main_process(self):
        return self.accelerator.is_main_process

    @property
    def params_for_training(self) -> list[Tensor]:
        # import pprint
        # logger.debug(f"params_for_training: {list(self.inference_pipeline.unet_unziplora.unziplora_weights.keys())}")
        res = list(self.inference_pipeline.unet_unziplora.unziplora_weights.values())
        res.extend(token_registrator.embeddings.weight for token_registrator in self.inference_pipeline.token_registrators)
        return res

    def compute_loss(self, model_pred: Tensor, target: Tensor, timesteps: Tensor) -> torch.Tensor:
        loss = get_loss(args=self.args, model_pred=model_pred, noise_scheduler=self.noise_scheduler, target=target, timesteps=timesteps)
        regularization_loss = self.inference_pipeline.get_regularization_loss() * self.args.regularization_weight
        logger.debug(f"loss: {repr(loss)}, regularization_loss: {repr(regularization_loss)}")
        # loss += self.args.regularization_weight * regularization_loss
        return loss + regularization_loss
        # raise NotImplementedError()

    # def _get_target(self, latents, noise, timesteps):
    #     return
    def _encode_latents(self, pixel_values):
        return create_model_input(self.args, pixel_values, self.vae, self.inference_pipeline.weight_dtype)


def get_loss(args, model_pred, noise_scheduler, target, timesteps) -> Tensor:
    # if args.with_prior_preservation:
    #     # Chunk the noise and model_pred into two parts and compute the loss on each part separately.
    #     model_pred, model_pred_prior = torch.chunk(model_pred, 2, dim=0)
    #     target, target_prior = torch.chunk(target, 2, dim=0)
    #
    #     # Compute prior loss
    #     prior_loss = F.mse_loss(
    #         model_pred_prior.float(), target_prior.float(), reduction="mean"
    #     )
    if args.snr_gamma is None:
        loss = F.mse_loss(
            model_pred.float(), target.float(), reduction="mean"
        )
    else:
        # Compute loss-weights as per Section 3.4 of https://arxiv.org/abs/2303.09556.
        # Since we predict the noise instead of x_0, the original formulation is slightly changed.
        # This is discussed in Section 4.2 of the same paper.
        snr = compute_snr(noise_scheduler, timesteps)
        base_weight = (
            torch.stack(
                [snr, args.snr_gamma * torch.ones_like(timesteps)], dim=1
            ).min(dim=1)[0]
            / snr
        )

        if noise_scheduler.config.prediction_type == "v_prediction":
            # Velocity objective needs to be floored to an SNR weight of one.
            mse_loss_weights = base_weight + 1
        else:
            # Epsilon and sample both use the same loss weights.
            mse_loss_weights = base_weight

        loss = F.mse_loss(
            model_pred.float(), target.float(), reduction="none"
        )
        loss = (
            loss.mean(dim=list(range(1, len(loss.shape))))
            * mse_loss_weights
        )
        loss = loss.mean()
    if args.with_prior_preservation:
        model_pred, model_pred_prior = torch.chunk(model_pred, 2, dim=0)
        target, target_prior = torch.chunk(target, 2, dim=0)

        # Compute prior loss
        prior_loss = F.mse_loss(
            model_pred_prior.float(), target_prior.float(), reduction="mean"
        )

        # Add the prior loss to the instance loss.
        loss = loss + args.prior_loss_weight * prior_loss
    return loss


def get_prediction_target(latents, noise, noise_scheduler, timesteps):
    # Get the target for loss depending on the prediction type
    if noise_scheduler.config.prediction_type == "epsilon":
        target = noise
    elif noise_scheduler.config.prediction_type == "v_prediction":
        target = noise_scheduler.get_velocity(latents, noise, timesteps)
    else:
        raise ValueError(
            f"Unknown prediction type {noise_scheduler.config.prediction_type}"
        )
    return target


def log_start_validation(args):
    logger.info(
        f"Running validation... \n Generating {args.num_validation_images} images with prompt:"
        f" {args.validation_prompt}."
    )


def is_validation_epoch(args, epoch=None):
    return (
        args.validation_prompt is not None
        and (epoch or 0) % args.validation_epochs == 0
        and args.num_validation_images > 0
    )


def log_start_training(args, total_batch_size, train_dataloader, train_dataset):
    logger.info("***** Running training *****")
    logger.info(f"  Num examples = {len(train_dataset)}")
    logger.info(f"  Num batches each epoch = {len(train_dataloader)}")
    logger.info(f"  Num Epochs = {args.num_train_epochs}")
    logger.info(f"  Instantaneous batch size per device = {args.train_batch_size}")
    logger.info(
        f"  Total train batch size (w. parallel, distributed & accumulation) = {total_batch_size}"
    )
    logger.info(f"  Gradient Accumulation steps = {args.gradient_accumulation_steps}")
    logger.info(f"  Total optimization steps = {args.max_train_steps}")


def get_total_batch_size(accelerator, args):
    return (
        args.train_batch_size
        * accelerator.num_processes
        * args.gradient_accumulation_steps
    )


def create_lr_scheduler(accelerator, args, optimizer) -> LRScheduler:
    lr_scheduler = get_scheduler(
        args.lr_scheduler,
        optimizer=optimizer,
        num_warmup_steps=args.lr_warmup_steps * accelerator.num_processes,
        num_training_steps=args.max_train_steps * accelerator.num_processes,
        num_cycles=args.lr_num_cycles,
        power=args.lr_power,
    )
    return lr_scheduler if accelerator is None else to_accelerator(lr_scheduler, accelerator)
